import numpy as np
import cv2

class Simple2DEnv:
    def __init__(self, width=200, height=200):
        self.width = width
        self.height = height
        self.reset()

    def reset(self):
        self.car_pos = [self.width//2, self.height-20]
        self.done = False
        self.step_count = 0
        self.max_steps = 100
        return self._get_state()

    def _get_state(self):
        img = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        cv2.line(img, (50, 0), (50, self.height), (255, 255, 255), 5)
        cv2.line(img, (150, 0), (150, self.height), (255, 255, 255), 5)
        cv2.rectangle(img, (self.car_pos[0]-5, self.car_pos[1]-5),
                      (self.car_pos[0]+5, self.car_pos[1]+5), (0, 0, 255), -1)
        return img

    def step(self, action):
        if action == 0:
            self.car_pos[0] -= 5
        elif action == 2:
            self.car_pos[0] += 5

        self.car_pos[0] = np.clip(self.car_pos[0], 0, self.width-1)
        self.car_pos[1] -= 2
        self.step_count += 1

        reward = 1
        if self.car_pos[0] < 50 or self.car_pos[0] > 150:
            reward = -10
            self.done = True

        if self.step_count >= self.max_steps:
            self.done = True

        return self._get_state(), reward, self.done