import cv2
import numpy as np
from environment import Simple2DEnv
from dqn_agent import DQNAgent
import torch
import imageio

env = Simple2DEnv()
input_shape = (3, env.height, env.width)
num_actions = 3

agent = DQNAgent(input_shape, num_actions)
agent.epsilon = 0.0  # Test mode

state = env.reset()
done = False
frames = []

while not done:
    action = agent.act(state)
    next_state, reward, done = env.step(action)
    state = next_state
    frames.append(state)

# Save video
height, width, layers = frames[0].shape
video = cv2.VideoWriter('run.mp4', cv2.VideoWriter_fourcc(*'mp4v'), 15, (width, height))

for frame in frames:
    video.write(frame)

video.release()
print("Video saved as run.mp4")

# Save GIF
imageio.mimsave('run.gif', frames, fps=15)