import cv2
import numpy as np
from environment import Simple2DEnv
from dqn_agent import DQNAgent

env = Simple2DEnv()
input_shape = (3, env.height, env.width)
num_actions = 3

agent = DQNAgent(input_shape, num_actions)
episodes = 500

for e in range(episodes):
    state = env.reset()
    total_reward = 0
    done = False

    while not done:
        action = agent.act(state)
        next_state, reward, done = env.step(action)
        agent.remember(state, action, reward, next_state, done)
        agent.replay()
        state = next_state
        total_reward += reward

    agent.update_target()
    print(f"Episode {e+1}/{episodes}, Total Reward: {total_reward}, Epsilon: {agent.epsilon:.2f}")